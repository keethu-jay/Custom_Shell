if cat haystack | grep -q needle ; then
	echo needle found
fi

