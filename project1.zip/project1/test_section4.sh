
echo Section 4 cd intrinsic
pwd
cd /tmp
pwd
cd /
pwd
cd usr
pwd
cd bin
pwd
cd ..
pwd
cd
pwd

