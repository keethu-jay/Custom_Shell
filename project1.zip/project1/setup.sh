# install dependencies
sudo apt install flex bison libreadline-dev